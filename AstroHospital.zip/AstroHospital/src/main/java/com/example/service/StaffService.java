package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.Patient;
import com.example.model.Staff;
import com.example.repo.PatientRepo;
import com.example.repo.StaffRepo;

@Service
public class StaffService {
	
	List<Staff> l1;
	
	@Autowired
	StaffRepo staffRepo;
	
	@Autowired
	PatientRepo patientRepo;
	
	public Staff addStaff(Staff staff) {
		
		//l1.add(staff);
		staff.setRole("ROLE_STAFF");
		Staff s1 = staffRepo.save(staff);
		return s1;
	}
	
	public Patient addPatient(Patient patient) {
		Patient pt1 = patientRepo.save(patient);
		return patient;
	}
	
	public List<Staff> getStaff(){
		return l1;
	}
}
