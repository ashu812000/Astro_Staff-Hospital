package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.Patient;
import com.example.model.Staff;
import com.example.repo.StaffRepo;
import com.example.service.StaffService;

@RestController
@RequestMapping("/hospital")
public class StaffController {
	
	@Autowired
	StaffService staffService;
	
	@Autowired
	StaffRepo staffRepo;
	
	@RequestMapping( value = "/signup", method = RequestMethod.POST)
	public Staff signup(@RequestBody Staff staff ) {
		System.out.println(staff);
		Staff stf = staffService.addStaff(staff);
		return stf;
	}
	
	@RequestMapping(value = "/addPatient", method = RequestMethod.POST)
	public Patient addPatient( @RequestBody Patient patient) {
		
		Patient pt1 = staffService.addPatient(patient);
		System.out.println(pt1);
		return pt1;
	}
	
	@RequestMapping(value = "/signup/getbymail/{email}", method = RequestMethod.GET)
	public Staff getstaff(@PathVariable String email) {
		Staff staff = staffRepo.getStaffByEmail(email);
		return staff;
	}
	
	@RequestMapping("/check")
	@ResponseBody
	public String check() {
		return "This is for checking";
	}
	
	@RequestMapping("/checkprivate")
	@ResponseBody
	public String checkprivate() {
		return "This is for Private checking";
	}
	
	
	
}
