package com.example.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.example.model.Staff;
import com.example.repo.StaffRepo;

public class CustomUserDetailServiceiimpl implements UserDetailsService {

	@Autowired
	private StaffRepo staffRepo;
	
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		
		Staff staff = staffRepo.getStaffByEmail(username);
		if (staff == null) {
			throw new UsernameNotFoundException("User not found !!!");
		}
		
		CustomUserDetails customUserDetails = new CustomUserDetails(staff);
		
		return customUserDetails;
	}
	
}
