package com.example.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.model.Staff;

public interface StaffRepo extends JpaRepository<Staff, Integer> {
	public Staff getStaffByEmail(String email);
}
